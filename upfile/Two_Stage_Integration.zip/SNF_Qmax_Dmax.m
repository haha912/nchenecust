function SNF_Qmax_Dmax(Dist1,Dist2,savepath)
addpath('./Cal_SNF/')
%%%First, set all the parameters.
K = 12;%number of neighbors, usually (10~30)
alpha = 0.36; %hyperparameter, usually (0.3~0.8)
T = 20; %Number of Iterations, usually (10~20)

%%%next, construct similarity graphs
W1 = affinityMatrix(Dist1, K, alpha);
W2 = affinityMatrix(Dist2, K, alpha);

% then the overall matrix can be computed by similarity network fusion(SNF):
SNF_QD = SNF({W1,W2}, K, T);

eval(['save ',savepath,'R_SNF.mat SNF_QD']);



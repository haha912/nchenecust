clear;
clc;
close all;

% cd D:/UIUC/composition/Two_Stage_Integration/WEKA
load ./Collection/Filename_799.mat;
Filename_799=Filename_799';
%load the file need to convert
load ./step2_fusion_similarity/BSC/BSC_799_QD.mat

[dis,dis_NoCover]=Cover_Distance_Decomposition(BSC_799_QD,Filename_799);
N=length(dis);

Feature=[dis,dis_NoCover]';
class=[ones(size(dis,2),1);zeros(size(dis_NoCover,2),1)];
%save arff file
mat2arff2(Feature, './step7_final_result/arff/CPCP/SIM_CPCP_799_QD_BN.arff',class);

(We use command line to call weka function ,you have to install weka first. Then, copy the weka.jar file to your current path, which you can find in the installation directory. In our case, we use vision of 3.8.1.)

Direction for use:

>Step1: use Cal_Dmax_Qmax.m to calculate Qmax and Dmax similarity of two feature.

>Step2: caculate fusion of Qmax and Dmax respectively with SNF_Qmax_Dmax.m.

>Step3: convert these .mat file to arff file that weka needed, use Get_WEKA_arff.m

>Step4: use Build_Weka_Model.m to build model for each feature

>Step5: get prediction data from weka batch with Get_Prediction_from_weka_batch.m

>Step6: convert prediction matrix to similarity matrix
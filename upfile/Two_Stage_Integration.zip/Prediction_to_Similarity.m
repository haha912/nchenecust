clc;
clear;


load F:\Two_Stage_Integration\Collection\Filename_160;
load F:\Two_Stage_Integration\WEKA\step5_weka_precious\BSC\P_BSC_799_QD_BN.mat;
listname=Filename_160;
N_Cover =2196;%number of cover
N_NonCover = 635406;%number of nocover

SIM=P_BSC_799_QD_BN;
cover = SIM(1:N_Cover);
noncover = SIM(N_Cover+1:end);
[SIM_BSC_799_QD_BN,Cover_Matrix, NonCover_Matrix] =  Cover_Distance_Composition( cover, noncover,listname);
save .\SIM_BSC_799_QD_BN.mat SIM_BSC_799_QD_BN

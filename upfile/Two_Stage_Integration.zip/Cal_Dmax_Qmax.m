function Cal_Dmax_Qmax(feature_path,savepath)
%feature_path: original feature path 
%savepath: save path of similarity file
AL=dir([feature_path,'*.mat']);
addpath(feature_path);
addpath('./Cal_Dmax_Qmax');
L=length(AL);
core_num=4;
if(isempty(gcp('nocreate')))
    p=parpool(core_num);
else
    p=gcp;
end
BSC_Qmax=zeros(L,L);
BSC_Dmax=zeros(L,L);
for i=1:L
    As=load(AL(i,1).name);
    %name of the feature have loaded 
    A=As.BeatChromas;
    parfor j=1:L
        disp([num2str(i),'---',num2str(j)]);
        Bs=load(AL(j,1).name);
        B=Bs.BeatChromas;
        %calculate CRP of two feature
        R1 = CRP(A,B);        
        BSC_Qmax(i,j)=Qmax(R1);
        BSC_Dmax(i,j)=Dmax(R1);
    end
    dstnme1=[savepath,'BSC_Qmax.mat'];%save name
    dstnme2=[savepath,'BSC_Dmax.mat'];
    eval( ['save(''',dstnme1,''',''','BSC_Qmax',''',''-v7.3'')'])
    eval( ['save(''',dstnme2,''',''','BSC_Dmax',''',''-v7.3'')'])
end
delete(p);

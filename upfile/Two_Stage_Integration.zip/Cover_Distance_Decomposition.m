function [Cover_Vector, NonCover_Vector,Cover_Matrix, NonCover_Matrix,...
    Cover_Sparse,NonCover_Sparse] = Cover_Distance_Decomposition( distance, listname, diagonalflag)
if nargin<3
    diagonalflag=1;
end
if nargin<2
    error('Please give listname!!!!');
end
%%%%%%%%%%

[~,Index] = Get_File_Information(listname);

Dmax = distance;
if diagonalflag
    Dmax = distance.*not(eye(size(distance)));
end
Index_Matrix = zeros(size(Dmax));
for i=1:max(Index)
    pos = find(Index==i);
    minpos = pos(1);
    maxpos = pos(end);
    Index_Matrix(minpos:maxpos,minpos:maxpos)=i.*ones(length(pos));
end
Index_Matrix(Index_Matrix>=1)=1;
Cover_Matrix = Dmax.*Index_Matrix;
NonCover_Matrix = Dmax.*not(Index_Matrix);

Cover_Sparse = sparse(Cover_Matrix');
NonCover_Sparse = sparse(NonCover_Matrix');

temp = Cover_Matrix';
temp(temp==0)=[];
Cover_Vector = temp;
temp = NonCover_Matrix';
temp(temp==0)=[];
NonCover_Vector = temp;
end


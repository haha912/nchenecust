function [Distance_Matrix,Cover_Matrix, NonCover_Matrix] = ...
    Cover_Distance_Composition( cover, noncover,listname, diagonalflag)
if nargin<4
    diagonalflag=1;
end
if nargin<2
    error('Please give listname!!!!');
end
if ~issparse(cover)&&nargin<3
    error('Non sparse, please at least input listfile name!!!!')
end
%%%%%%%%%%
if issparse(cover)
    Cover_Matrix = full(cover)';
    NonCover_Matrix = full(noncover)';
    Distance_Matrix = Cover_Matrix + NonCover_Matrix;
else
    [~,Index] = Get_File_Information(listname);
    N = length(Index);
    xindex=[];
    yindex=[];
    for i=1:N
        pos = find(Index==Index(i));
        if diagonalflag
            pos(pos==i)=[];
        end
        xindex=[xindex pos];
        yindex=[yindex i*ones(1,length(pos))];
    end
    cover_matrix = sparse(xindex, yindex, cover, N, N);
    Cover_Matrix = full(cover_matrix)';
    
    xindex=[];
    yindex=[];
    for i=1:length(Index)
        pos = find(Index~=Index(i));
        xindex=[xindex pos];
        yindex=[yindex i*ones(1,length(pos))];
    end
    noncover_matrix = sparse(xindex, yindex, noncover, N, N);
    NonCover_Matrix = full(noncover_matrix)';
    Distance_Matrix = Cover_Matrix + NonCover_Matrix;
end
end


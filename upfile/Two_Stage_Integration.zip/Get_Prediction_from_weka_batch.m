clear
% cd D:/Two_Stage_Integration/WEKA
if(exist('mkmatlab.txt','file')==2)
    delete('mkmatlab.txt');
end
Wekapath='./';% file path of weka.jar
Datapath='F:/Two_Stage_Integration/WEKA/step3_get_arff/BSC/';% filepath of test data
Modelpath='F:/Two_Stage_Integration/WEKA/step4_weka_model/BSC/';%filepath of the model build last step
PSavepath='F:/Two_Stage_Integration/WEKA/step5_weka_precious/';%save path

Classifier={'bayes.BayesNet'};%type of classifier
% Classifier_Short={'BN'};%��������д
% DatasetNum=1;%����������
% Setnum={'801','799','802','962'};fclose all;%  '801','799','802','962'
Features={'MLD'};%��������  'HPCP','BSC','MLD'
P=0; %Outputs predictions for test instances

BuildedModel=[Modelpath,'Model_BSC_801_QD_3_BN.model'];%fall path of model
TestData=[Datapath,'BSC_799_QD.arff'];%fall path of testdata
%dear.txt and mkmatlab.txt is transfer file 
Order=['! java -cp ',Wekapath,'weka.jar weka.classifiers.',Classifier{1},' -T ',TestData,' -l ',BuildedModel,' -p ',num2str(P),' > dear.txt'];
eval(Order);%
fidin=fopen('dear.txt');                                % ��test2.txt�ļ�
fidout=fopen('mkmatlab.txt','w');                       % ����MKMATLAB.txt�ļ�
while ~feof(fidin)                                      % �ж��Ƿ�Ϊ�ļ�ĩβ
	tline=fgetl(fidin);                                 % ���ļ�����
	if ~isempty(tline)&&length(tline)>9&&(double(tline(9))>=48&&double(tline(9))<=57)%!!!!!�����98��Ҫ����weka�汾�Ķ�,�˴�Ϊ3.8
        t=strrep(tline,':c1','');
        t=strrep(t,':c0','');
        t=strrep(t,'+',' ');
        fprintf(fidout,'%s\n',t); % ����������У��Ѵ�������д���ļ�MKMATLAB.txt
	end
end
fclose all;
delete('dear.txt');
load('MKMATLAB.txt');% �����ɵ�MKMATLAB.txt�ļ����빤���ռ䣬������ΪMK
MKS=zeros(length(MKMATLAB),1);
for ii=1:length(MKMATLAB)
    if((MKMATLAB(ii,2)==MKMATLAB(ii,3)&&MKMATLAB(ii,2)==2)||(MKMATLAB(ii,2)~=MKMATLAB(ii,3)&&MKMATLAB(ii,2)==1))
        MKS(ii,1)=MKMATLAB(ii,4);
    else
        MKS(ii,1)=1-MKMATLAB(ii,4);
    end
end
SName=[PSavepath,'P_BSC_799_BN.mat'];% _',DPer,'
eval(['save ',SName,' MKS'])
fclose all;
delete('mkmatlab.txt');

fprintf('Analysis Done!\n');
% General options:
% -h or -help
%         Output help information.
% -synopsis or -info
%         Output synopsis for classifier (use in conjunction  with -h)
% -t <name of training file>
%         Sets training file.
% -T <name of test file>
%         Sets test file. If missing, a cross-validation will be performed
%         on the training data.
% -c <class index>
%         Sets index of class attribute (default: last).
% -x <number of folds>
%         Sets number of folds for cross-validation (default: 10).
% -no-cv
%         Do not perform any cross validation.
% -force-batch-training
%         Always train classifier in batch mode, never incrementally.
% -split-percentage <percentage>
%         Sets the percentage for the train/test set split, e.g., 66.
% -preserve-order
%         Preserves the order in the percentage split.
% -s <random number seed>
%         Sets random number seed for cross-validation or percentage split
%         (default: 1).
% -m <name of file with cost matrix>
%         Sets file with cost matrix.
% -toggle <comma-separated list of evaluation metric names>
%         Comma separated list of metric names to toggle in the output.
%         All metrics are output by default with the exception of 'Coverage' and '
% Region size'.
%         Available metrics:
%         Correct,Incorrect,Kappa,Total cost,Average cost,KB relative,KB informati
% on,
%         Correlation,Complexity 0,Complexity scheme,Complexity improvement,
%         MAE,RMSE,RAE,RRSE,Coverage,Region size,TP rate,FP rate,Precision,Recall,
%
%         F-measure,MCC,ROC area,PRC area
% -l <name of input file>
%         Sets model input file. In case the filename ends with '.xml',
%         a PMML file is loaded or, if that fails, options are loaded
%         from the XML file.
% -d <name of output file>
%         Sets model output file. In case the filename ends with '.xml',
%         only the options are saved to the XML file, not the model.
% -v
%         Outputs no statistics for training data.
% -o
%         Outputs statistics only, not the classifier.
% -do-not-output-per-class-statistics
%         Do not output statistics for each class.
% -k
%         Outputs information-theoretic statistics.
% -classifications "weka.classifiers.evaluation.output.prediction.AbstractOutput +
%  options"
%         Uses the specified class for generating the classification output.
%         E.g.: weka.classifiers.evaluation.output.prediction.PlainText
% -p range
%         Outputs predictions for test instances (or the train instances if
%         no test instances provided and -no-cv is used), along with the
%         attributes in the specified range (and nothing else).
%         Use '-p 0' if no attributes are desired.
%         Deprecated: use "-classifications ..." instead.
% -distribution
%         Outputs the distribution instead of only the prediction
%         in conjunction with the '-p' option (only nominal classes).
%         Deprecated: use "-classifications ..." instead.
% -r
%         Only outputs cumulative margin distribution.
% -z <class name>
%         Only outputs the source representation of the classifier,
%         giving it the supplied name.
% -g
%         Only outputs the graph representation of the classifier.
% -xml filename | xml-string
%         Retrieves the options from the XML-data instead of the command line.
% -threshold-file <file>
%         The file to save the threshold data to.
%         The format is determined by the extensions, e.g., '.arff' for ARFF
%         format or '.csv' for CSV.
% -threshold-label <label>
%         The class label to determine the threshold data for
%         (default is the first label)
% -no-predictions
%         Turns off the collection of predictions in order to conserve memory.
%
% Options specific to weka.classifiers.trees.J48:
%
% -U
%         Use unpruned tree.
% -O
%         Do not collapse tree.
% -C <pruning confidence>
%         Set confidence threshold for pruning.
%         (default 0.25)
% -M <minimum number of instances>
%         Set minimum number of instances per leaf.
%         (default 2)
% -R
%         Use reduced error pruning.
% -N <number of folds>
%         Set number of folds for reduced error
%         pruning. One fold is used as pruning set.
%         (default 3)
% -B
%         Use binary splits only.
% -S
%         Do not perform subtree raising.
% -L
%         Do not clean up after the tree has been built.
% -A
%         Laplace smoothing for predicted probabilities.
% -J
%         Do not use MDL correction for info gain on numeric attributes.
% -Q <seed>
%         Seed for random data shuffling (default 1).
% -doNotMakeSplitPointActualValue
%         Do not make split point actual value.
% -output-debug-info
%         If set, classifier is run in debug mode and
%         may output additional info to the console
% -do-not-check-capabilities
%         If set, classifier capabilities are not checked before classifier is bui
% lt
%         (use with caution).
% -num-decimal-places
%         The number of decimal places for the output of numbers in the model (def
% ault 2).
% -batch-size
%         The desired batch size for batch prediction  (default 100).